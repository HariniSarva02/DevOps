function Footer() {
    return (
      <footer>
        <div>
          <strong>SR University</strong>
          <span>Student Management Dashboard</span>
        </div>
  
        <p>© 2026 SR University. All rights reserved.</p>
      </footer>
    );
  }
  
  export default Footer;