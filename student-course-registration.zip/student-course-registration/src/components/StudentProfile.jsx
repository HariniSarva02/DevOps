function StudentProfile() {
    return (
      <section>
        <h2>Student Profile</h2>
        <p>Name: Harini</p>
        <p>Student ID: 2303A510B7</p>
        <p>Department: Computer Science and Engineering</p>
      </section>
    );
  }
  
  export default StudentProfile;