function Footer() {
    return (
      <footer>
        <p>© 2026 SR University</p>
        <p>Student Course Registration System</p>
      </footer>
    );
  }
  
  export default Footer;