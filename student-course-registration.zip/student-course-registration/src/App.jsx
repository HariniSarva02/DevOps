import { useState } from "react";
import "./App.css";
import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import CourseList from "./components/CourseList";
import Registration from "./components/Registration";
import Footer from "./components/Footer";

function App() {
  const [registeredCourses, setRegisteredCourses] = useState([]);

  const handleRegister = (course) => {
    setRegisteredCourses((previousCourses) => {
      const alreadyRegistered = previousCourses.some(
        (item) => item.name === course.name
      );

      if (alreadyRegistered) {
        return previousCourses;
      }

      return [...previousCourses, course];
    });
  };

  const handleRemove = (courseName) => {
    setRegisteredCourses((previousCourses) =>
      previousCourses.filter((course) => course.name !== courseName)
    );
  };

  return (
    <>
      <Header />

      <main>
        <StudentProfile />

        <CourseList onRegister={handleRegister} />

        <Registration
          registeredCourses={registeredCourses}
          onRemove={handleRemove}
        />
      </main>

      <Footer />
    </>
  );
}

export default App;