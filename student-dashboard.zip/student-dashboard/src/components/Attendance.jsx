function Attendance({ percentage }) {
    const eligible = percentage >= 75;
  
    return (
      <section className="dashboard-card attendance-card">
        <div className="card-heading">
          <div>
            <p className="small-label">PERFORMANCE</p>
            <h2>Attendance</h2>
          </div>
  
          <div className={eligible ? "eligible" : "not-eligible"}>
            {eligible ? "✓ Eligible" : "✕ Not Eligible"}
          </div>
        </div>
  
        <div className="attendance-content">
          <div
            className="attendance-circle"
            style={{
              background: `conic-gradient(#6d61df ${percentage}%, #ececf4 0)`
            }}
          >
            <div>
              <strong>{percentage}%</strong>
              <span>Attendance</span>
            </div>
          </div>
  
          <div className="attendance-info">
            <h3>
              {eligible ? "Good Attendance!" : "Attendance Needs Attention"}
            </h3>
  
            <p>
              Your attendance is {eligible ? "above" : "below"} the
              minimum requirement of 75%.
            </p>
  
            <div className="progress-container">
              <div
                className="progress-bar"
                style={{ width: `${percentage}%` }}
              ></div>
            </div>
  
            <div className="progress-labels">
              <span>0%</span>
              <span>Minimum: 75%</span>
              <span>100%</span>
            </div>
          </div>
        </div>
      </section>
    );
  }
  
  export default Attendance;