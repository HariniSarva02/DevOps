const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = 3000;

const JWT_SECRET = "student_api_secret_key";

// Middleware
app.use(express.json());

// In-memory users
const users = [];

// In-memory students
const students = [
    {
        id: 1,
        name: "Harini",
        age: 20,
        course: "B.Tech CSE"
    },
    {
        id: 2,
        name: "Rahul",
        age: 21,
        course: "B.Tech CSE"
    }
];

// Request logging middleware
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

// JWT Authentication Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers["authorization"];

    if (!authHeader) {
        return res.status(401).json({
            message: "Unauthorized: JWT token is missing"
        });
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            message: "Unauthorized: Invalid Authorization header"
        });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(401).json({
                message: "Unauthorized: Invalid or expired JWT token"
            });
        }

        req.user = user;
        next();
    });
}

// Home API
app.get("/", (req, res) => {
    res.json({
        message: "Welcome to Secure Student API"
    });
});

// Register API
app.post("/register", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    const existingUser = users.find(
        user => user.username === username
    );

    if (existingUser) {
        return res.status(409).json({
            message: "User already exists"
        });
    }

    const newUser = {
        id: users.length + 1,
        username,
        password,
        role: "student"
    };

    users.push(newUser);

    res.status(201).json({
        message: "User registered successfully",
        user: {
            id: newUser.id,
            username: newUser.username,
            role: newUser.role
        }
    });
});

// Login API
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    const user = users.find(
        user =>
            user.username === username &&
            user.password === password
    );

    if (!user) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    const token = jwt.sign(
        {
            userId: user.id,
            username: user.username,
            role: user.role
        },
        JWT_SECRET,
        {
            expiresIn: "1h"
        }
    );

    res.json({
        message: "Login successful",
        token: token
    });
});

// Protected GET /students
app.get("/students", authenticateToken, (req, res) => {
    res.json({
        message: "Students retrieved successfully",
        students: students
    });
});

// Protected POST /students
app.post("/students", authenticateToken, (req, res) => {
    const { name, age, course } = req.body;

    if (!name || !age || !course) {
        return res.status(400).json({
            message: "Name, age and course are required"
        });
    }

    const newStudent = {
        id: students.length + 1,
        name,
        age,
        course
    };

    students.push(newStudent);

    res.status(201).json({
        message: "Student added successfully",
        student: newStudent
    });
});

// Protected GET /students/:id
app.get("/students/:id", authenticateToken, (req, res) => {
    const id = parseInt(req.params.id);

    const student = students.find(
        student => student.id === id
    );

    if (!student) {
        return res.status(404).json({
            message: "Student not found"
        });
    }

    res.json({
        message: "Student retrieved successfully",
        student: student
    });
});

// 404 middleware
app.use((req, res) => {
    res.status(404).json({
        message: "Route not found"
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`=================================`);
    console.log(`Secure Student API`);
    console.log(`Server running on port ${PORT}`);
    console.log(`http://localhost:${PORT}`);
    console.log(`=================================`);
});