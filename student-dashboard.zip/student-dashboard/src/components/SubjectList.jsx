function SubjectList({ subjects }) {
    return (
      <section className="dashboard-card subjects-card">
        <div className="card-heading">
          <div>
            <p className="small-label">ACADEMICS</p>
            <h2>My Subjects</h2>
          </div>
  
          <span className="count-badge">
            {subjects.length} Subjects
          </span>
        </div>
  
        <div className="subject-list">
          {subjects.map((subject, index) => (
            <div className="subject-item" key={index}>
              <div className="subject-number">
                {String(index + 1).padStart(2, "0")}
              </div>
  
              <div className="subject-info">
                <strong>{subject.name}</strong>
                <span>{subject.code}</span>
              </div>
  
              <span className="subject-arrow">›</span>
            </div>
          ))}
        </div>
      </section>
    );
  }
  
  export default SubjectList;