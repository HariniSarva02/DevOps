function Header() {
    return (
      <header className="top-header">
        <div className="brand">
          <div className="logo">SU</div>
          <div>
            <h1>SR University</h1>
            <p>Student Management Portal</p>
          </div>
        </div>
  
        <div className="header-badge">
          <span className="status-dot"></span>
          Academic Year 2026–27
        </div>
      </header>
    );
  }
  
  export default Header;