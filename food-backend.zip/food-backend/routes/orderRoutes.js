const express = require("express");
const router = express.Router();

// In-memory storage: orders reset when the container is recreated.
const orders = [];
let nextOrderId = 1;

router.post("/", (req, res) => {
  const { customerName, items } = req.body;

  if (typeof customerName !== "string" || !customerName.trim()) {
    return res.status(400).json({ message: "customerName is required" });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ message: "items must be a non-empty array" });
  }

  const order = {
    id: nextOrderId++,
    customerName: customerName.trim(),
    items,
    status: "PLACED",
    createdAt: new Date().toISOString()
  };

  orders.push(order);
  res.status(201).json({ message: "Order placed successfully", order });
});

router.get("/", (req, res) => {
  res.json(orders);
});

module.exports = router;
