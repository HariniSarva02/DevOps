import Navbar from "./components/Navbar";
import StudentProfile from "./components/StudentProfile";
import SubjectList from "./components/SubjectList";
import Attendance from "./components/Attendance";
import ExamDetails from "./components/ExamDetails";
import QuickActions from "./components/QuickActions";
import Announcements from "./components/Announcements";
import Footer from "./components/Footer";

function App() {
  const student = {
    name: " Harini",
    rollNumber: " 2303A510B7",
    branch: " Computer Science Engineering",
    year: " 4th Year"
  };

  const subjects = [
    {
      name: "Data Structures",
      code: "CS201"
    },
    {
      name: "Database Management Systems",
      code: "CS202"
    },
    {
      name: "Operating Systems",
      code: "CS203"
    },
    {
      name: "Machine Learning",
      code: "CS204"
    },
    {
      name: "Web Development",
      code: "CS205"
    }
  ];

  return (
    <div className="student-hub">

      <Navbar />

      <main id="home" className="main-content">

        <section className="hero-section">

          <div className="hero-text">
            <p className="eyebrow">GOOD MORNING, VISHNU 👋</p>

            <h1>
              Your academic journey,
              <br />
              <span>all in one place.</span>
            </h1>

            <p className="hero-description">
              Stay organized, keep track of your progress and
              never miss an important academic update.
            </p>
          </div>

          <div className="hero-date">
            <span>FRIDAY</span>
            <strong>11</strong>
            <span>SEPTEMBER 2026</span>
          </div>

        </section>

        <QuickActions />

        <section className="overview-grid">

          <div id="academics">
            <StudentProfile
              name={student.name}
              rollNumber={student.rollNumber}
              branch={student.branch}
              year={student.year}
            />
          </div>

          <Attendance percentage={85} />

        </section>

        <section className="content-grid">

          <SubjectList subjects={subjects} />

          <ExamDetails />

        </section>

        <Announcements />

      </main>

      <Footer />

    </div>
  );
}

export default App;