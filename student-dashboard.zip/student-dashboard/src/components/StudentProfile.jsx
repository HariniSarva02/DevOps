function StudentProfile({ name, rollNumber, branch, year }) {
    return (
      <section className="profile-card">
        <div className="profile-top">
          <div className="avatar">
            {name.charAt(0).toUpperCase()}
          </div>
  
          <div>
            <p className="small-label">STUDENT PROFILE</p>
            <h2>{name}</h2>
            <p className="student-role">Computer Science Student</p>
          </div>
        </div>
  
        <div className="profile-details">
          <div>
            <span>Roll Number</span>
            <strong>{rollNumber}</strong>
          </div>
  
          <div>
            <span>Branch</span>
            <strong>{branch}</strong>
          </div>
  
          <div>
            <span>Year</span>
            <strong>{year}</strong>
          </div>
        </div>
  
        <button className="profile-button">
          View Profile →
        </button>
      </section>
    );
  }
  
  export default StudentProfile;