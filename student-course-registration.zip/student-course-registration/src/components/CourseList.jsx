import { useState } from "react";
import Course from "./Course";

function CourseList({ onRegister }) {
  const courses = [
    {
      name: "Web Development",
      department: "CSE",
      credits: 4
    },
    {
      name: "Machine Learning",
      department: "CSE",
      credits: 4
    },
    {
      name: "Cloud Computing",
      department: "CSE",
      credits: 3
    },
    {
      name: "Database Management Systems",
      department: "CSE",
      credits: 3
    },
    {
      name: "Artificial Intelligence",
      department: "AI",
      credits: 4
    }
  ];

  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("All");

  const filteredCourses = courses.filter((course) => {
    const matchesSearch = course.name
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesDepartment =
      department === "All" || course.department === department;

    return matchesSearch && matchesDepartment;
  });

  return (
    <section>
      <h2>Available Courses</h2>

      <input
        type="text"
        placeholder="Search course name"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <select
        value={department}
        onChange={(e) => setDepartment(e.target.value)}
      >
        <option value="All">All Departments</option>
        <option value="CSE">CSE</option>
        <option value="AI">AI</option>
      </select>

      {filteredCourses.length === 0 ? (
        <p>No courses found.</p>
      ) : (
        filteredCourses.map((course) => (
          <Course
            key={course.name}
            name={course.name}
            department={course.department}
            credits={course.credits}
            onRegister={onRegister}
          />
        ))
      )}
    </section>
  );
}

export default CourseList;