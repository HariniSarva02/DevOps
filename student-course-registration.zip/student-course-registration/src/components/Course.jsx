function Course({ name, department, credits, onRegister }) {
    return (
      <div>
        <h3>{name}</h3>
        <p>Department: {department}</p>
        <p>Credits: {credits}</p>
  
        <button onClick={() => onRegister({ name, department, credits })}>
          Register
        </button>
      </div>
    );
  }
  
  export default Course;