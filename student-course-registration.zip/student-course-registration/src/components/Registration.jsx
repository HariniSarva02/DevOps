function Registration({ registeredCourses, onRemove }) {
    const totalCredits = registeredCourses.reduce(
      (total, course) => total + course.credits,
      0
    );
  
    return (
      <section>
        <h2>Registered Courses</h2>
  
        {registeredCourses.length === 0 ? (
          <p>No courses are registered.</p>
        ) : (
          <>
            {registeredCourses.map((course) => (
              <div key={course.name}>
                <h3>{course.name}</h3>
                <p>Department: {course.department}</p>
                <p>Credits: {course.credits}</p>
  
                <button onClick={() => onRemove(course.name)}>
                  Remove
                </button>
              </div>
            ))}
  
            <h3>Total Registered Credits: {totalCredits}</h3>
          </>
        )}
      </section>
    );
  }
  
  export default Registration;