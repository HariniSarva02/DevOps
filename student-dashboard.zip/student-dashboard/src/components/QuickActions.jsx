function QuickActions() {
    const actions = [
      { icon: "📊", title: "Attendance", text: "Check percentage" },
      { icon: "📚", title: "Subjects", text: "View courses" },
      { icon: "📝", title: "Exams", text: "Exam schedule" },
      { icon: "📅", title: "Schedule", text: "Today's classes" }
    ];
  
    return (
      <section className="quick-actions">
        {actions.map((action, index) => (
          <div className="action-card" key={index}>
            <div className="action-icon">{action.icon}</div>
            <div>
              <strong>{action.title}</strong>
              <span>{action.text}</span>
            </div>
            <span className="action-arrow">→</span>
          </div>
        ))}
      </section>
    );
  }
  
  export default QuickActions;