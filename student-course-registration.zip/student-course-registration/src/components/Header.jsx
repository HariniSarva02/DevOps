function Header() {
    return (
      <header>
        <h1>SR University</h1>
  
        <nav>
          <a href="#">Home</a>
          <a href="#">Courses</a>
          <a href="#">Registration</a>
        </nav>
      </header>
    );
  }
  
  export default Header;