function ExamDetails() {
    return (
      <section className="dashboard-card exam-card">
        <div className="card-heading">
          <div>
            <p className="small-label">EXAMINATION</p>
            <h2>Exam Details</h2>
          </div>
  
          <span className="upcoming-badge">Upcoming</span>
        </div>
  
        <div className="exam-main">
          <div className="calendar-icon">📅</div>
  
          <div>
            <h3>Semester Examination</h3>
            <p>End Semester Examination – 2026</p>
          </div>
        </div>
  
        <div className="exam-details">
          <div>
            <span>Exam Date</span>
            <strong>20 October 2026</strong>
          </div>
  
          <div>
            <span>Semester</span>
            <strong>Odd Semester</strong>
          </div>
  
          <div>
            <span>Status</span>
            <strong className="status-text">Upcoming</strong>
          </div>
        </div>
      </section>
    );
  }
  
  export default ExamDetails;