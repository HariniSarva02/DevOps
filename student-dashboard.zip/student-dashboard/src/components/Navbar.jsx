function Navbar() {
    return (
      <nav className="navbar">
        <div className="nav-brand">
          <div className="nav-logo">SU</div>
          <span>StudentHub</span>
        </div>
  
        <div className="nav-links">
          <a href="#home" className="active">Home</a>
          <a href="#academics">Academics</a>
          <a href="#campus">Campus</a>
          <a href="#exams">Exams</a>
        </div>
  
        <div className="nav-profile">
          <div className="mini-avatar">V</div>
          <div>
            <strong>Vishnu</strong>
            <span>Student</span>
          </div>
          <span className="down-arrow">⌄</span>
        </div>
      </nav>
    );
  }
  
  export default Navbar;