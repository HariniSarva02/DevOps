function Announcements() {
    const announcements = [
      {
        tag: "EXAM",
        title: "Semester examination timetable released",
        date: "Today"
      },
      {
        tag: "EVENT",
        title: "Annual college hackathon registrations are open",
        date: "Yesterday"
      },
      {
        tag: "NOTICE",
        title: "Library timing extended during examination week",
        date: "2 days ago"
      }
    ];
  
    return (
      <section className="announcements">
        <div className="section-title">
          <div>
            <p className="eyebrow">STAY UPDATED</p>
            <h2>Campus Announcements</h2>
          </div>
  
          <button>View all →</button>
        </div>
  
        <div className="announcement-list">
          {announcements.map((item, index) => (
            <div className="announcement" key={index}>
              <div className="announcement-icon">📢</div>
  
              <div className="announcement-content">
                <span className={`announcement-tag tag-${index}`}>
                  {item.tag}
                </span>
                <h3>{item.title}</h3>
                <p>{item.date}</p>
              </div>
  
              <span className="announcement-arrow">→</span>
            </div>
          ))}
        </div>
      </section>
    );
  }
  
  export default Announcements;